package neotech;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.webapplication.service.neotech.model.Product;
import com.webapplication.service.neotech.client.ProductClient;


public class ProductClientTest {
	
	@Test
	public void testGetProduct() {
		ProductClient client = new ProductClient();
		Response product = client.getProduct(1);
		System.out.println(product.readEntity(Product.class));
		assertNotNull(product);
	}
	
	@Test(expected = RuntimeException.class)
	public void testGetBadRequest() {
		ProductClient client = new ProductClient();
		Response response = client.getProduct(-2);
		assertEquals(Response.status(Status.BAD_REQUEST).build(),response);
	}
	
	@Test(expected = RuntimeException.class)
	public void testGetRequestNotFound() {
		ProductClient client = new ProductClient();
		Response response = client.getProduct(9999999);
		assertEquals(Response.status(Status.NOT_FOUND).build(),response);
	}
	
	@Test
	public void testGetAllProducts(){
		ProductClient client = new ProductClient();
		List<Product> products = client.getAllProducts();
		assertNotNull(products);
	}
	
	@Test public void testAddProduct() { 
		ProductClient client = new ProductClient(); 
		Response added = client.addProduct(new Product(3, 20000f,"Hello moto", "Motrola")); 
		assertNotNull(added); 
	}
	  
	@Test public void testUpdateProduct() { 
		ProductClient client = new ProductClient();
		Response updated = client.updateProduct(1, new Product(1, 15000f, "Innovation Never Stands Still", "Lenovo"));
		assertNotNull(updated);
	 }
	  
	 @Test public void testDeleteProduct() {
		 ProductClient client = new ProductClient(); 
		 Response deleted = client.deleteProduct(2);
		 assertNotNull(deleted);
	}
	 
}
