package com.webapplication.service.neotech.repository;

import java.util.ArrayList;
import java.util.List;

import com.webapplication.service.neotech.model.Product;

public class ProductStub implements ProductRepository {
	static List<Product> products = new ArrayList<Product>();

	
	  static{ 
		  products.add(new Product(products.size()+1, 15000f, "connecting people", "Nokia mobile"));
		  products.add(new Product(products.size()+1, 10000f, "Create the future", "SamSung"));
	  }
	 
	@Override
	public List<Product> getAllProducts() {
		return products;
	}

	@Override
	public Product getProduct(int productId) {
		for(Product product : products) {
			if(product.getProductId()==productId) {
				return product;
			}
		}
		return null;
	}

	@Override
	public int addProduct(Product product) {
		System.out.println("Before add : ");
		ProductStub.printall();
		int newProductId = products.size()+1;
		product.setProductId(newProductId);
		products.add(product);
		System.out.println("After add : ");
		ProductStub.printall();
		return newProductId;
	}
	
	public static void printall() {
		for(Product product : products) {
			System.out.println(product.getProductId()+" "+product.getProductName());
		}
	}

	public Product findProduct(int productId) {
		Product foundedProduct = null;
		for(Product product : products) {
			if(product.getProductId()==productId) {
				foundedProduct= product;
				break;
			}
		}
		return foundedProduct;
	}
	
	@Override
	public boolean updateProduct(int productId, Product product) {
		System.out.println("Before update : ");
		ProductStub.printall();
		Product toUpdate = new ProductStub().findProduct(productId);
		int index = products.indexOf(toUpdate);
		if (index >= 0) {
			product.setProductId(productId);
			products.set(index, product);
			System.out.println("After update : ");
			ProductStub.printall();
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteProduct(int productId) {
		System.out.println("Before delete : ");
		ProductStub.printall();
		Product toDelete = new ProductStub().findProduct(productId);
		int index = products.indexOf(toDelete);
		if (index >= 0) {
			System.out.println(index);
			products.remove(index);
			System.out.println("After delete : ");
			ProductStub.printall();
			return true;
		}
		return false;
	}

}
